package thehungryknight;

import java.util.Scanner;

/**
 *
 * @author Martell Norman
 * CS 232 - 002
 * The HUngry Knight:
 * This program allows you to play as a knight staying at a tavern waiting to be roomed and fed.
 * Its up to you to decide how much you and your men should be fed.
 * Due Date: Sept. 5, 2022
 */
public class TheHungryKnight 
{
    //User Input command line
    static Scanner console = new Scanner(System.in);
    
    //Prices for the food and taxes
    static  final double ROAST_PHEASANT_PRICE = 15.15;
    static  final double BEEF_STEW_PRICE = 3.79;
    static  final double BREAD_PRICE = 5.37;
    static  final double FRUIT_PRICE = 1.29;
    static  final int TAX = 5;
    
    public static void main(String[] args) 
    {
        //declaring variables
        String name; //Use String instead of int
        String characteristic; //Use String instead of int
        double totalPrice_noTAX;
        double totalPrice_pheasant;
        double totalPrice_stew;
        double totalPrice_bread;
        double totalPrice_fruit;
        double totalPrice_withTAX;
        int pheasant;
        int stew;
        int bread;
        int fruit;
        
        //Welcomes the User to the program when ran and ask the user for input
        System.out.println("Hello Traveler, or may I say Sir Knight. Welcome to my humble Inn.\nShall I get you name Sir Knight?");
        name = console.next(); //Take out int on "next();" when using String operators
        characteristic = console.next();
        
        //The program will great the user with the info added and will ask what the user would like to eat
        System.out.println("Well Sir " + name + " the " 
                + characteristic + ", I have a fine selection of food for you and your men. So please, tell me: ");
        
        //User will now enter what they would want for each item
        System.out.println("\nHow many Roast Pheasant do you and your men want?");
        pheasant = console.nextInt();
        System.out.println("How many bowls of Beef Stew do you and your men want?");
        stew = console.nextInt();
        System.out.println("How many loaf, or loafs, of fine bread do you and your men want?");
        bread = console.nextInt();
        System.out.println("How many pieces of fine fruit, or fruits, do you and your men want?");
        fruit = console.nextInt();
        
        //Reads out user inputed information
        System.out.println("So that is:\n" 
                + pheasant +" Roasted Pheasants\n" 
                + stew + " Bowls of Stew\n" 
                + bread + " Loafs of Bread\n" 
                + fruit + " Pieces of fine fruit");
        
        //Math WITHOUT Taxes
        totalPrice_pheasant = pheasant * ROAST_PHEASANT_PRICE;
        totalPrice_stew = stew * BEEF_STEW_PRICE;
        totalPrice_bread = bread * BREAD_PRICE;
        totalPrice_fruit = fruit * FRUIT_PRICE;
        totalPrice_noTAX = totalPrice_pheasant + totalPrice_stew + totalPrice_bread + totalPrice_fruit;
        System.out.println("In total, this will cost you " + Math.round(totalPrice_noTAX) + " gold without taxes.");
        
        //Math WITH Taxes
        totalPrice_withTAX = Math.round(totalPrice_noTAX) * TAX;
        System.out.println("And with taxes, the total will be you " + totalPrice_withTAX + " gold with tax.");
    }
    
}
